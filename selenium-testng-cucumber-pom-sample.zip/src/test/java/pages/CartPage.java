package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;

public class CartPage {
    private WebDriver driver;
    private By cartItems = By.cssSelector(".cart_item");

    public CartPage(WebDriver driver){
        this.driver = driver;
    }

    public int getNumberOfItems(){
        return driver.findElements(cartItems).size();
    }
}
