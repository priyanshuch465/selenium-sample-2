package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;

public class ProductsPage {
    private WebDriver driver;
    private By firstAddToCart = By.cssSelector(".inventory_list .inventory_item:first-of-type button");
    private By shoppingCartBadge = By.className("shopping_cart_badge");
    private By cartLink = By.className("shopping_cart_link");

    public ProductsPage(WebDriver driver){
        this.driver = driver;
    }

    public void addFirstProductToCart(){
        driver.findElement(firstAddToCart).click();
    }

    public String getCartCount(){
        try {
            return driver.findElement(shoppingCartBadge).getText();
        } catch (Exception e){
            return "0";
        }
    }

    public void goToCart(){
        driver.findElement(cartLink).click();
    }
}
