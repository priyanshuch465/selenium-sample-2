package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.By;

public class HomePage {
    private WebDriver driver;
    private By title = By.className("title");

    public HomePage(WebDriver driver){
        this.driver = driver;
    }

    public String getTitleText(){
        return driver.findElement(title).getText();
    }
}
