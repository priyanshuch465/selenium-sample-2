package stepDefinitions;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.*;
import org.testng.Assert;
import org.openqa.selenium.WebDriver;
import utils.TestBase;
import pages.*;

public class Steps {
    private WebDriver driver;
    private LoginPage loginPage;
    private HomePage homePage;
    private ProductsPage productsPage;
    private CartPage cartPage;

    @Before
    public void setup(){
        TestBase.initDriver();
        driver = TestBase.driver;
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
        productsPage = new ProductsPage(driver);
        cartPage = new CartPage(driver);
    }

    @After
    public void teardown(){
        TestBase.quitDriver();
    }

    @Given("I open the saucedemo login page")
    public void i_open_the_saucedemo_login_page() {
        loginPage.open();
    }

    @When("I login with username {string} and password {string}")
    public void i_login_with_username_and_password(String user, String pass) {
        loginPage.login(user, pass);
    }

    @Then("I should see the products page")
    public void i_should_see_the_products_page() {
        Assert.assertTrue(homePage.getTitleText().toLowerCase().contains("products"));
    }

    @When("I add the first product to the cart")
    public void i_add_the_first_product_to_the_cart() {
        productsPage.addFirstProductToCart();
    }

    @Then("the cart should have 1 item")
    public void the_cart_should_have_1_item() {
        Assert.assertEquals(productsPage.getCartCount(), "1");
        productsPage.goToCart();
        Assert.assertEquals(cartPage.getNumberOfItems(), 1);
    }
}
