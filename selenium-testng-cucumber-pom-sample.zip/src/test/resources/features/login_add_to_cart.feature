Feature: Login and add to cart

  Scenario: Successful login and add a product to cart
    Given I open the saucedemo login page
    When I login with username "standard_user" and password "secret_sauce"
    Then I should see the products page
    When I add the first product to the cart
    Then the cart should have 1 item
